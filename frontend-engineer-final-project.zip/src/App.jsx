import HomePage from './pages/Home/Home';

function App() {
  return (
    <div>
      <HomePage />
    </div>
  );
}

export default App;
